<?php require_once('Connections/www.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_www, $www);
$query_login = "SELECT * FROM usersdata";
$login = mysql_query($query_login, $www) or die(mysql_error());
$row_login = mysql_fetch_assoc($login);
$totalRows_login = mysql_num_rows($login);

$colname_RecUser = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_RecUser = $_SESSION['MM_Username'];
}
mysql_select_db($database_www, $www);
$query_RecUser = sprintf("SELECT * FROM usersdata WHERE user_loginid = %s", GetSQLValueString($colname_RecUser, "text"));
$RecUser = mysql_query($query_RecUser, $www) or die(mysql_error());
$row_RecUser = mysql_fetch_assoc($RecUser);
$totalRows_RecUser = mysql_num_rows($RecUser);

$colname_Recordset1 = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_Recordset1 = $_SESSION['MM_Username'];
}
mysql_select_db($database_www, $www);
$query_Recordset1 = sprintf("SELECT * FROM usersdata WHERE user_loginid = %s", GetSQLValueString($colname_Recordset1, "text"));
$Recordset1 = mysql_query($query_Recordset1, $www) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['user_login'])) {
  $loginUsername=$_POST['user_login'];
  $password=$_POST['user_pwd'];
  $MM_fldUserAuthorization = "user_type";
  $MM_redirectLoginSuccess = "login.php";
  $MM_redirectLoginFailed = "loginnew.php";
  $MM_redirecttoReferrer = false;
  mysql_select_db($database_www, $www);
  	
  $LoginRS__query=sprintf("SELECT user_loginid, user_pwd, user_type FROM usersdata WHERE user_loginid=%s AND user_pwd=%s",
  GetSQLValueString($loginUsername, "text"), GetSQLValueString($password, "text")); 
   
  $LoginRS = mysql_query($LoginRS__query, $www) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
    
    $loginStrGroup  = mysql_result($LoginRS,0,'user_type');
    
	if (PHP_VERSION >= 5.1) {session_regenerate_id(true);} else {session_regenerate_id();}
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;	      

    if (isset($_SESSION['PrevUrl']) && false) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
    header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
    header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>旅遊查詢系統</title>
	<link rel="shortcut icon" type="image/x-icon" href="css/images/favicon.ico" />
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="all" />
	
	<script src="js/jquery-1.7.2.min.js" type="text/javascript"></script>
	<!--[if lt IE 9]>
		<script src="js/modernizr.custom.js"></script>
	<![endif]-->
	<script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
	<script src="js/functions.js" type="text/javascript"></script>
    <script language="javascript">
function myAlert(){
document.getElementById("layer1").style.visibility="visible";
}
function hiddenAlert(){
document.getElementById("layer1").style.visibility="hidden"
}
</script>
</head>
<body>
	<!-- wrapper -->
	<div id="wrapper">
		<!-- shell -->
		<div class="shell">
			<!-- container -->
			<div class="container">
							
				<!-- header -->
				<header class="header">
                  <?php if ($totalRows_Recordset1 > 0) { // Show if recordset not empty ?>
  <table><tr>
    <td><?php echo $row_Recordset1['user_name']; ?>&nbsp;&nbsp;&nbsp;您好！</td></tr></table>
  <?php } // Show if recordset not empty ?>
<nav id="navigation">
			  <ul>
						  <li ><a href="./movie.html">影片</a></li>
							<li><a href="./search.php">查詢</a></li>
							<li onClick="myAlert()"><a>留言</a></li>
							
							
		  </ul>
				  </nav>
					
			  </header>
				<!-- end of header -->
				<div class="main">
					<!-- slider -->
					<div class="flexslider">
						<ul class="slides">
							<li>
							<a href="../index.php"><img src="css/images/slide-img1.jpg" alt="" width="100%" height="330"></a>
								
								
							</li>
							
							
						</ul>
					</div>
					<!-- end of slider -->
					<!-- cols -->
					<section class="cols">
					</section> <form ACTION="<?php echo $loginFormAction; ?>" METHOD="POST">              
<div style="border-style:solid; border-width:1px; position: absolute; width: 300px; height:300px; z-index: 1; left: 35%; top: 30%; visibility:hidden; background-color:#EEE" id="layer1">
<table cellspacing="15" cellpadding="0" border="0" width="100%" height="100%">
<tr>
  <?php if ($totalRows_Recordset1 == 0) { // Show if recordset empty ?>
<td colspan="2" align="center" style="color:#00F; font-size:20pt; font-family:Microsoft JhengHei;" >登入</td></tr>
<tr><td style="color:#00F" >帳號</td>
<td> <input name="user_login" type="text" id="user_login" style="width:150px; height:32px;" size="33" /></td>
</tr>
<tr><td style="color:#00F">密碼</td>
<td><input name="user_pwd" type="password" id="user_pwd" style="width:150px; height:32px;" size="33" /></td>
</tr>

<tr ><td></td>
<td align="right"><input type="submit" name="Submit3" value="登入" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="button" name="Submit2" value="註冊" onClick="window.location.href = 'register.php'" /></td>
<?php } // Show if recordset empty ?>
</tr>
</table>
</div></form>  
					<!-- end of cols  -->

					<!-- box --><!-- end of box -->
					
					<!-- services -->
					<section class="services">
						<div class="widget">
							<h3>小組成員：<br>資3B 0124038 宋彥陞  資3B 01240342 辜致豪  資3B 0124096 林慶龍</h3>
							<!-- <p>資3B 0124038 宋彥陞</p> -->
							<!-- <br><br>資3B 01240342 辜致豪<br><br>資3B 0124096 林慶龍 -->
						</div>
						
						<div class="widget socials-widget">
						<!-- 	<h3>Get Social</h3>
							<p>Lorem ipsum dolor sit amet eu.</p> -->
							<a href="#" class="facebook-ico">facebook</a>
							<a href="#" class="twitter-ico">twitter</a>
							<a href="#" class="rss-ico">rss</a>
							<a href="#" class="in-ico">in</a>
							<a href="#" class="skype-ico">skype</a>
							<a href="#" class="google-ico">google</a>
						</div>
						<div class="cl">&nbsp;</div>
					</section>
					<!-- end of services -->

				</div>
				<!-- end of main -->
			</div>
			<!-- end of container -->	
			<div class="footer">
			  <p class="copy">Copyright &copy; 2014 All Rights Reserved. Design by NKFUST</p>
			</div>
		</div>
		<!-- end of shell -->
	</div>
	<!-- end of wrappert -->
</body>
</html>
<?php
mysql_free_result($login);

mysql_free_result($RecUser);

mysql_free_result($Recordset1);
?>
