<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_www = "localhost";
$database_www = "travel_system";
$username_www = "root";
$password_www = "root";
$www = mysql_pconnect($hostname_www, $username_www, $password_www) or trigger_error(mysql_error(),E_USER_ERROR); 
?>