<?php require_once('Connections/www.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$maxRows_travelData = 10;
$pageNum_travelData = 0;


$query_travelData = "SELECT * FROM travel";
$query_limit_travelData = sprintf("%s LIMIT %d, %d", $query_travelData, $startRow_travelData, $maxRows_travelData);
$travelData = mysql_query($query_limit_travelData, $www) or die(mysql_error());
$row_travelData = mysql_fetch_assoc($travelData);

if (isset($_GET['totalRows_travelData'])) {
  $totalRows_travelData = $_GET['totalRows_travelData'];
} else {
  $all_travelData = mysql_query($query_travelData);
  $totalRows_travelData = mysql_num_rows($all_travelData);
}
$totalPages_travelData = ceil($totalRows_travelData/$maxRows_travelData)-1;

$queryString_travelData = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_travelData") == false && 
        stristr($param, "totalRows_travelData") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_travelData = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_travelData = sprintf("&totalRows_travelData=%d%s", $totalRows_travelData, $queryString_travelData);

$maxRows_travelData = 10;
$pageNum_travelData = 0;
if (isset($_GET['pageNum_travelData'])) {
  $pageNum_travelData = $_GET['pageNum_travelData'];
}
$startRow_travelData = $pageNum_travelData * $maxRows_travelData;


if (isset($_GET['day'])){$day=$_GET['day'];}
if (isset($_GET['agency'])){$agency=$_GET['agency'];}
if (isset($_GET['site'])){$site=$_GET['site'];}
if (isset($_GET['price1'])&&$_GET['price1']!=''){$price1=$_GET['price1'];}
else{$price1='0';}
if (isset($_GET['price2'])&&$_GET['price2']!=''){$price2=$_GET['price2'];}
else{$price2='99999';}

mysql_select_db($database_www, $www);
$query_travelData = "SELECT * FROM travel WHERE travel_day like '$day' and travel_agency like '$agency' and travel_site like '$site' and travel_price > $price1 and travel_price < $price2";
$query_limit_travelData = sprintf("%s LIMIT %d, %d", $query_travelData, $startRow_travelData, $maxRows_travelData);
$travelData = mysql_query($query_limit_travelData, $www) or die(mysql_error());
$row_travelData = mysql_fetch_assoc($travelData);





if (isset($_GET['totalRows_travelData'])) {
  $totalRows_travelData = $_GET['totalRows_travelData'];
} else {
  $all_travelData = mysql_query($query_travelData);
  $totalRows_travelData = mysql_num_rows($all_travelData);
}
$totalPages_travelData = ceil($totalRows_travelData/$maxRows_travelData)-1;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>旅遊查詢系統-查詢</title>
	<link rel="shortcut icon" type="image/x-icon" href="css/images/favicon.ico" />
	<link rel="stylesheet" href="css/style_search.css" type="text/css" media="all" />
	<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="all" />
	
	<script src="js/jquery-1.7.2.min.js" type="text/javascript"></script>
	<!--[if lt IE 9]>
		<script src="js/modernizr.custom.js"></script>
	<![endif]-->
	<script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
	<script src="js/functions.js" type="text/javascript"></script>
</head>

<body>
<!-- wrapper -->
	<div id="wrapper">
		<!-- shell -->
		<div class="shell">
			<!-- container -->
			<div class="container">
							
				<!-- header -->
				<header class="header">
					<h1 id="logo"></h1>
					<nav id="navigation">
						<ul>
							<li ><a href="./movie.html">影片</a></li>
							<li><a href="./search.php">查詢</a></li>
							<li><a href="./hi/hi_show.php">留言</a></li>
							<li><a href="./index.php">登出</a></li>
							
						</ul>
					</nav>
					<div class="cl">&nbsp;</div>
				</header>
				<!-- end of header -->
				<div class="main">
					<!-- slider -->
					<div class="flexslider">
						<ul class="slides">
							<li>
								<a href="../index.php"><img src="css/images/slide-img1.jpg" alt="" width="100%" height="330"></a>
								
								
							</li>
							
							
						</ul>
					</div>
					<!-- end of slider -->
					<!-- cols -->
					<section class="cols">
						<form name="search" action="search_result.php" method=get>
                            <span class="search-rule">請選擇查詢天數：</span>
<select name="day">
              <option value=%>-
              <option value=1>1
              <option value=2>2
              <option value=3>3
              <option value=4>4
              <option value=9>4天以上
                   </select>
                            <span class="search-rule">請選擇查詢價格：</span>
                          <input type="text" name="price1" >
                         ~
                      <input type="text" name="price2" >
                           <span class="search-rule">請選擇查詢旅行社：</span>
<select name="agency">
              <option value=%>- 
              <option value=燦星旅遊>燦星旅遊
              <option value=可樂旅遊>可樂旅遊
              <option value=雄獅旅遊>雄獅旅遊
              </select>
                            <span class="search-rule">請選擇查詢地點：</span>
<select name="site">
              <option value=%>- 
              <option value=台北>台北
              <option value=台中>台中
              <option value=台南>台南
              <option value=宜蘭>宜蘭
              <option value=高雄>高雄
              <option value=屏東>屏東
              <option value=澎湖>澎湖
              </select>
                            
 
  <input type=submit value="查詢">
                            <br>
</form>
                        <div style="height:10pt;"> </div>  
                        <div class="search-start" >
                        全部項目
                        </div>
<div style="height:10pt;"> </div>  
						<?php do { ?>
					    <div class="coll">
					        <span class="search-title">旅遊行程：</a>
						      <a href="<?php echo $row_travelData['travel_URL']; ?>">
                              <?php echo $row_travelData['travel_route']; ?></a></span><br>
                          <span class="search-item">天數：<?php echo $row_travelData['travel_day']; ?> <br>價格： 	
						      <?php echo $row_travelData['travel_price']; ?><br>旅行社：<?php echo $row_travelData['travel_agency']; ?> <br>地點：	
						      <?php echo $row_travelData['travel_site']; ?></span>
						    
						    
					      </div>

					      <div></div>
					    <?php } while ($row_travelData = mysql_fetch_assoc($travelData)); ?>
<div style="height:10pt;"> </div>  
						
                        <table width="22%" border="0" align="right" >
                          <tr>
                            <td align="center"><?php if ($pageNum_travelData > 0) { // Show if not first page ?>
                                <a href="<?php printf("%s?pageNum_travelData=%d%s", $currentPage, 0, $queryString_travelData); ?>"><img src="First.gif" /><br>第一頁</a>
                                <?php } // Show if not first page ?></td>
                            <td align="center"><?php if ($pageNum_travelData > 0) { // Show if not first page ?>
                                <a href="<?php printf("%s?pageNum_travelData=%d%s", $currentPage, max(0, $pageNum_travelData - 1), $queryString_travelData); ?>"><img src="Previous.gif" /><br>上一頁</a>
                                <?php } // Show if not first page ?></td>
                            <td align="center"><?php if ($pageNum_travelData < $totalPages_travelData) { // Show if not last page ?>
                                <a href="<?php printf("%s?pageNum_travelData=%d%s", $currentPage, min($totalPages_travelData, $pageNum_travelData + 1), $queryString_travelData); ?>"><img src="Next.gif" /><br>下一頁</a>
                                <?php } // Show if not last page ?></td>
                            <td align="center"><?php if ($pageNum_travelData < $totalPages_travelData) { // Show if not last page ?>
                                <a href="<?php printf("%s?pageNum_travelData=%d%s", $currentPage, $totalPages_travelData, $queryString_travelData); ?>"><img src="Last.gif" /><br>最後一頁</a>
                                <?php } // Show if not last page ?></td>
                          </tr>
                        </table>
                   <div style="height:10pt;"> </div>  
                    </section>
					<!-- end of cols  -->

					<!-- box --><!-- end of box -->
					
					<!-- services -->
					<section class="services">
						<div class="widget">
							<h3>小組成員：<br>資3B 0124038 宋彥陞  資3B 01240342 辜致豪  資3B 0124096 林慶龍</h3>
							<!-- <p>資3B 0124038 宋彥陞</p> -->
							<!-- <br><br>資3B 01240342 辜致豪<br><br>資3B 0124096 林慶龍 -->
						</div>
						
						<div class="widget socials-widget">
						<!-- 	<h3>Get Social</h3>
							<p>Lorem ipsum dolor sit amet eu.</p> -->
							<a href="#" class="facebook-ico">facebook</a>
							<a href="#" class="twitter-ico">twitter</a>
							<a href="#" class="rss-ico">rss</a>
							<a href="#" class="in-ico">in</a>
							<a href="#" class="skype-ico">skype</a>
							<a href="#" class="google-ico">google</a>
						</div>
						<div class="cl">&nbsp;</div>
					</section>
					<!-- end of services -->

				</div><code></code>
				<!-- end of main -->
			</div>
			<!-- end of container -->	
			<div class="footer">
			  <p class="copy">Copyright &copy; 2014 All Rights Reserved. Design by NKFUST</p>
			</div>
		</div>
		<!-- end of shell -->
	</div>
	<!-- end of wrappert -->

</body>
</html>
<?php
mysql_free_result($travelData);
?>
