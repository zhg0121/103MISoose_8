<?php require_once('Connections/www.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_www, $www);
$query_Recordset1 = "SELECT user_loginid FROM usersdata";
$Recordset1 = mysql_query($query_Recordset1, $www) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);$colname_Recordset1 = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_Recordset1 = $_SESSION['MM_Username'];
}
mysql_select_db($database_www, $www);
$query_Recordset1 = sprintf("SELECT user_loginid FROM usersdata WHERE user_loginid = %s", GetSQLValueString($colname_Recordset1, "text"));
$Recordset1 = mysql_query($query_Recordset1, $www) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>旅遊查詢系統</title>
	<link rel="shortcut icon" type="image/x-icon" href="css/images/favicon.ico" />
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="all" />
	
	<script src="js/jquery-1.7.2.min.js" type="text/javascript"></script>
	<!--[if lt IE 9]>
		<script src="js/modernizr.custom.js"></script>
	<![endif]-->
	<script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
	<script src="js/functions.js" type="text/javascript"></script>
</head>
<body>
	<!-- wrapper -->
	<div id="wrapper">
		<!-- shell -->
		<div class="shell">
			<!-- container -->
			<div class="container">
							
				<!-- header -->
				<header class="header">
					<h1 id="logo"></h1>
					<nav id="navigation">
						<ul>
                        	
						  <li ><a href="./movie.html">影片</a></li>
							<li><a href="./search.php">查詢</a></li>
							<li><a href="./hi/hi_show.php">留言</a></li>
                          <li><a href="./index.php">登出</a></li>
                         
                        </ul>
					</nav>
					<div class="cl">&nbsp;</div>
				</header>
				<!-- end of header -->
				<div class="main">
					<!-- slider -->
					<div class="flexslider">
						<ul class="slides">
							<li>
								<a href="#"><img src="css/images/slide-img1.jpg" alt="" width="100%" height="330"></a>
								
								
							</li>
							
							
						</ul>
					</div>
					<!-- end of slider -->
					<!-- cols -->
					<section class="cols">
						

						<div class="col">
							<h3><img src="css/images/1-t11.jpg" alt="" width="200" height="100"/></h3>
							<p>雄獅旅遊網提供國外團體旅遊、台灣團體旅遊、機票、訂房、自由行、航空假期、票券、高鐵及主題旅遊等全方位服務，提供最完善的旅遊資訊，致力成為全球旅人最喜愛....</p>
							<a href="http://www.liontravel.com/" class="col-btn">更多...</a>
						</div>

						<div class="col">
							<h3><img src="css/images/1-t21.jpg" alt="" width="200" height="100"/></h3>
							<p>可樂旅遊提供國內外團體旅遊、自由行、機票、飯店、郵輪、護照簽證等旅遊商品，以及員工旅遊、商務差旅、獎勵旅遊等客製化服務，價格最實惠、品質有口碑，是您個人最佳...</p>
							<a href="http://www.colatour.com.tw/" class="col-btn">更多...</a>
						</div>

						<div class="col">
							<h3><img src="css/images/1-t31.jpg" alt="" width="200" height="100"/></h3>
							<p>擁有精選旅行團行程規劃，無論是國際航線、國內旅遊，來燦星您可以輕鬆找到合適的旅遊行程。東京線、東北亞、港澳大陸等等，都有相對應的團體自由行 ...</p>
							<a href="http://www.startravel.com.tw/" class="col-btn">更多...</a>
						</div>
						<div class="cl">&nbsp;</div>
					</section>
					<!-- end of cols  -->

					<!-- box --><!-- end of box -->
					
					<!-- services -->
					<section class="services">
						<div class="widget">
							<h3>小組成員：<br>資3B 0124038 宋彥陞  資3B 01240342 辜致豪  資3B 0124096 林慶龍</h3>
							<!-- <p>資3B 0124038 宋彥陞</p> -->
							<!-- <br><br>資3B 01240342 辜致豪<br><br>資3B 0124096 林慶龍 -->
						</div>
						
						<div class="widget socials-widget">
						<!-- 	<h3>Get Social</h3>
							<p>Lorem ipsum dolor sit amet eu.</p> -->
							<a href="#" class="facebook-ico">facebook</a>
							<a href="#" class="twitter-ico">twitter</a>
							<a href="#" class="rss-ico">rss</a>
							<a href="#" class="in-ico">in</a>
							<a href="#" class="skype-ico">skype</a>
							<a href="#" class="google-ico">google</a>
						</div>
						<div class="cl">&nbsp;</div>
					</section>
					<!-- end of services -->

				</div>
				<!-- end of main -->
			</div>
			<!-- end of container -->	
			<div class="footer">
			  <p class="copy">Copyright &copy; 2014 All Rights Reserved. Design by NKFUST</p>
			</div>
		</div>
		<!-- end of shell -->
	</div>
	<!-- end of wrappert -->
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
