<?php require_once('../Connections/www.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

mysql_select_db($database_www, $www);
$query_Recordset1 = "SELECT * FROM gbdata";
$Recordset1 = mysql_query($query_Recordset1, $www) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);

$queryString_Recordset1 = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_Recordset1") == false && 
        stristr($param, "totalRows_Recordset1") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_Recordset1 = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_Recordset1 = sprintf("&totalRows_Recordset1=%d%s", $totalRows_Recordset1, $queryString_Recordset1);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf8" />
	<title>旅遊查詢系統</title>
	<link rel="shortcut icon" type="image/x-icon" href="css/images/favicon.ico" />
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="all" />
	
	<script src="js/jquery-1.7.2.min.js" type="text/javascript"></script>
	<!--[if lt IE 9]>
		<script src="js/modernizr.custom.js"></script>
	<![endif]-->
	<script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
	<script src="js/functions.js" type="text/javascript"></script>

<!-- 頁籤切換 -->
<script type="text/javascript">
	$(function(){
		// 預設顯示第一個 Tab
		var _showTab = 0;
		var $defaultLi = $('ul.tabs li').eq(_showTab).addClass('active');
		$($defaultLi.find('a').attr('href')).siblings().hide();
		
		// 當 li 頁籤被點擊時...
		// 若要改成滑鼠移到 li 頁籤就切換時, 把 click 改成 mouseover
		$('ul.tabs li').click(function() {
			// 找出 li 中的超連結 href(#id)
			var $this = $(this),
				_clickTab = $this.find('a').attr('href');
			// 把目前點擊到的 li 頁籤加上 .active
			// 並把兄弟元素中有 .active 的都移除 class
			$this.addClass('active').siblings('.active').removeClass('active');
			// 淡入相對應的內容並隱藏兄弟元素
			$(_clickTab).stop(false, true).fadeIn().siblings().hide();

			return false;
		}).find('a').focus(function(){
			this.blur();
		});
	});
</script>
</head>
<body>
	<!-- wrapper -->
	<div id="wrapper">
		<!-- shell -->
		<div class="shell">
			<!-- container -->
			<div class="container">
							
				<!-- header -->
				<header class="header">
					<h1 id="logo"></h1>
					<nav id="navigation">
						<ul>
							<li ><a href="../movie.html">影片</a></li>
							<li><a href="../search.php">查詢</a></li>
							<li><a href="../hi/hi_show.php">留言</a></li>
							<li><a href="../index.php">登出</a></li>
							
						</ul>
					</nav>
					<div class="cl">&nbsp;</div>
				</header>
				<!-- end of header -->
				<div class="main">
					<!-- slider -->
					<div class="flexslider">
						<ul class="slides">
							<li>
								<a href="../index.php"><img src="css/images/slide-img1.jpg" alt="" /></a>
								
								
							</li>
							
							
						</ul>
					</div>
					<!-- end of slider -->
					<!-- cols -->
					<section class="cols">
						<div align="center">
<P align="right"> <a href="hi_write.php">前往留言</p>
                          <?php do { ?>
                          <?php if ($totalRows_Recordset1 > 0) { // Show if recordset not empty ?>
  <table width="510" border="1">
   
    <tr>
      <td height="74" align="center">留言內容：</td>
      <td align="center"><?php echo $row_Recordset1['gb_content']; ?></td>
      </tr>
    <tr>
      <td align="center">回應內容：</td>
      <td align="center"><?php echo $row_Recordset1['reply_content']; ?></td>
      </tr>
    <tr>
      <td align="center">回應時間：</td>
      <td align="center"><?php echo $row_Recordset1['reply_time']; ?></td>
      </tr>
  </table>
  <a href="hi_admin.php?gb_id=<?php echo $row_Recordset1['gb_id']; ?>"><img src="icon_reply_topic.gif" width="16" height="16" alt="回應"></a>
  <?php } // Show if recordset not empty ?>
<?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?>
<p>&nbsp;</p>
<?php if ($totalRows_Recordset1 == 0) { // Show if recordset empty ?>
  <table width="510" border="1">
    <tr align="center">
      <td width="510" height="67" align="center">對不起，目前留言簿沒有留言!<br>
        請留言吧~~</td>
    </tr>
  </table>
  <?php } // Show if recordset empty ?>
<p>&nbsp;</p>
<table width="510" border="1">
  
  <tr align="center">
    <td width="464" height="20" align="center">&nbsp;
記錄 <?php echo ($startRow_Recordset1 + 1) ?> 到 <?php echo min($startRow_Recordset1 + $maxRows_Recordset1, $totalRows_Recordset1) ?> 共 <?php echo $totalRows_Recordset1 ?></td>
    <td width="30" align="center"><table border="0">
      <tr>
          <td><?php if ($pageNum_Recordset1 > 0) { // Show if not first page ?>
              <a href="<?php printf("%s?pageNum_Recordset1=%d%s", $currentPage, 0, $queryString_Recordset1); ?>"><img src="First.gif"></a>
              <?php } // Show if not first page ?></td>
          <td><?php if ($pageNum_Recordset1 > 0) { // Show if not first page ?>
              <a href="<?php printf("%s?pageNum_Recordset1=%d%s", $currentPage, max(0, $pageNum_Recordset1 - 1), $queryString_Recordset1); ?>"><img src="Previous.gif"></a>
              <?php } // Show if not first page ?></td>
          <td><?php if ($pageNum_Recordset1 < $totalPages_Recordset1) { // Show if not last page ?>
              <a href="<?php printf("%s?pageNum_Recordset1=%d%s", $currentPage, min($totalPages_Recordset1, $pageNum_Recordset1 + 1), $queryString_Recordset1); ?>"><img src="Next.gif"></a>
              <?php } // Show if not last page ?></td>
          <td><?php if ($pageNum_Recordset1 < $totalPages_Recordset1) { // Show if not last page ?>
              <a href="<?php printf("%s?pageNum_Recordset1=%d%s", $currentPage, $totalPages_Recordset1, $queryString_Recordset1); ?>"><img src="Last.gif"></a>
              <?php } // Show if not last page ?></td>
        </tr>
    </table></td>
  </tr>
  
</table>

	                  </div>
						




						<div class="cl">&nbsp;</div>
					</section>
					<!-- end of cols  -->

					<!-- box --><!-- end of box -->
					
					<!-- services -->
					<section class="services">
						<div class="widget">
							<h3>小組成員：<br>資3B 0124038 宋彥陞  資3B 01240342 辜致豪  資3B 0124096 林慶龍</h3>
							<!-- <p>資3B 0124038 宋彥陞</p> -->
							<!-- <br><br>資3B 01240342 辜致豪<br><br>資3B 0124096 林慶龍 -->
						</div>
						
						<div class="widget socials-widget">
						<!-- 	<h3>Get Social</h3>
							<p>Lorem ipsum dolor sit amet eu.</p> -->
							<a href="#" class="facebook-ico">facebook</a>
							<a href="#" class="twitter-ico">twitter</a>
							<a href="#" class="rss-ico">rss</a>
							<a href="#" class="in-ico">in</a>
							<a href="#" class="skype-ico">skype</a>
							<a href="#" class="google-ico">google</a>
						</div>
						<div class="cl">&nbsp;</div>
					</section>
					<!-- end of services -->

				</div>
				<!-- end of main -->
			</div>
			<!-- end of container -->	
			<div class="footer">
			  <p class="copy">Copyright &copy; 2014 All Rights Reserved. Design by NKFUST</p>
			</div>
		</div>
		<!-- end of shell -->
	</div>
	<!-- end of wrappert -->
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
