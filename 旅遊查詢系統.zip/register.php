<?php require_once('Connections/www.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

// *** Redirect if username exists
$MM_flag="MM_insert";
if (isset($_POST[$MM_flag])) {
  $MM_dupKeyRedirect="register_error.php";
  $loginUsername = $_POST['user_login'];
  $LoginRS__query = sprintf("SELECT user_loginid FROM usersdata WHERE user_loginid=%s", GetSQLValueString($loginUsername, "text"));
  mysql_select_db($database_www, $www);
  $LoginRS=mysql_query($LoginRS__query, $www) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);

  //if there is a row in the database, the username was found - can not add the requested username
  if($loginFoundUser){
    $MM_qsChar = "?";
    //append the username to the redirect page
    if (substr_count($MM_dupKeyRedirect,"?") >=1) $MM_qsChar = "&";
    $MM_dupKeyRedirect = $MM_dupKeyRedirect . $MM_qsChar ."requsername=".$loginUsername;
    header ("Location: $MM_dupKeyRedirect");
    exit;
  }
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form")) {
  $insertSQL = sprintf("INSERT INTO usersdata (user_loginid, user_pwd, user_name, user_sex, user_email) VALUES (%s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['user_login'], "text"),
                       GetSQLValueString($_POST['user_pwd'], "text"),
                       GetSQLValueString($_POST['user_name'], "text"),
                       GetSQLValueString($_POST['user_sex'], "text"),
                       GetSQLValueString($_POST['user_mail'], "text"));

  mysql_select_db($database_www, $www);
  $Result1 = mysql_query($insertSQL, $www) or die(mysql_error());

  $insertGoTo = "login.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_www, $www);
$query_login = "SELECT * FROM usersdata";
$login = mysql_query($query_login, $www) or die(mysql_error());
$row_login = mysql_fetch_assoc($login);
$totalRows_login = mysql_num_rows($login);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>旅遊查詢系統</title>
	<link rel="shortcut icon" type="image/x-icon" href="css/images/favicon.ico" />
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="all" />
	
	<script src="js/jquery-1.7.2.min.js" type="text/javascript"></script>
	<!--[if lt IE 9]>
		<script src="js/modernizr.custom.js"></script>
	<![endif]-->
	<script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
	<script src="js/functions.js" type="text/javascript"></script>
</head>
<body>
	<!-- wrapper -->
	<div id="wrapper">
		<!-- shell -->
		<div class="shell">
			<!-- container -->
			<div class="container">
							
				<!-- header -->
				<header class="header">
					<h1 id="logo"></h1>
					<nav id="navigation">
						<ul>
							<li ><a href="./movie.html">影片</a></li>
							<li><a href="./search.php">查詢</a></li>
							<li><a href="./hi/hi_show.php">留言</a></li>
							<li><a href="./login.php">登入</a></li>
							
						</ul>
					</nav>
					<div class="cl">&nbsp;</div>
				</header>
				<!-- end of header -->
				<div class="main">
					<!-- slider -->
					<div class="flexslider">
						<ul class="slides">
							<li>
								<a href="../index.php"><img src="css/images/slide-img1.jpg" alt="" width="100%" height="330"></a>
								
								
							</li>
							
							
						</ul>
					</div>
					<!-- end of slider -->
					<!-- cols -->
					<section class="cols">
						
					<form action="<?php echo $editFormAction; ?>" METHOD="POST" name="form">
						<div  >
							<div  class="logdiv">
                           <img src="css/images/lo.png" alt="" width="123px" height="123px">
                            </div>
                      
						</div>

						 <div style="height:20px; background-color:#EEE;"></div>
						<div style="background-color:#EEE; color:blue;" >
                      帳號
                      <input name="user_login" type="text" id="user_login" style="width:150px; height:32px;" size="33" />
                      </div>
                      <div style="height:20px; background-color:#EEE; "></div>
                        <div style="background-color:#EEE;color:blue;" >
                        密碼
                        <input name="user_pwd" type="password" id="user_pwd" style="width:150px; height:32px;" size="33" />
                        </div>
                         <div style="height:20px; background-color:#EEE;"></div>
                      <div style="background-color:#EEE;color:blue;" >
                        姓名
                        <input name="user_name" type="text" id="user_pwd" style="width:150px; height:32px;" size="33" />
                        </div>
                         <div style="height:20px; background-color:#EEE;"></div>
                      <div style="background-color:#EEE;color:blue;" >
                        性別
                         <input name="user_sex" type="radio" value="男" checked="checked" />
                  男
                  <input type="radio" name="user_sex" value="女" />
                  女
                        </div>
                         <div style="height:20px; background-color:#EEE;"></div>
                      <div style="background-color:#EEE;color:blue;" >
                        電子信箱
                        <input name="user_mail" type="text" id="user_pwd" style="width:150px; height:32px;" size="33" />
                        </div>
                        <div style="height:20px; background-color:#EEE;"></div>
                      <div style="background-color:#EEE;" class="logdiv">
                      <input type="submit" name="Submit3" value="送出" />
                      <input type="hidden" name="MM_insert" value="form">  
                        </form>
				  </section>
					<!-- end of cols  -->

					<!-- box --><!-- end of box -->
					
					<!-- services -->
					<section class="services">
						<div class="widget">
							<h3>小組成員：<br>資3B 0124038 宋彥陞  資3B 01240342 辜致豪  資3B 0124096 林慶龍</h3>
							<!-- <p>資3B 0124038 宋彥陞</p> -->
							<!-- <br><br>資3B 01240342 辜致豪<br><br>資3B 0124096 林慶龍 -->
						</div>
						
						<div class="widget socials-widget">
						<!-- 	<h3>Get Social</h3>
							<p>Lorem ipsum dolor sit amet eu.</p> -->
							<a href="#" class="facebook-ico">facebook</a>
							<a href="#" class="twitter-ico">twitter</a>
							<a href="#" class="rss-ico">rss</a>
							<a href="#" class="in-ico">in</a>
							<a href="#" class="skype-ico">skype</a>
							<a href="#" class="google-ico">google</a>
						</div>
						<div class="cl">&nbsp;</div>
					</section>
					<!-- end of services -->

				</div>
				<!-- end of main -->
			</div>
			<!-- end of container -->	
			<div class="footer">
			  <p class="copy">Copyright &copy; 2014 All Rights Reserved. Design by NKFUST</p>
			</div>
		</div>
		<!-- end of shell -->
	</div>
	<!-- end of wrappert -->
</body>
</html>
<?php
mysql_free_result($login);
?>
